import ComingSoonPage from '@/components/coming-soon-page'
import { Building2 } from 'lucide-react'

export default function HostelPage() {
  return (
    <ComingSoonPage
      title="Hostel / Dormitory Management"
      description="Manage hostel accommodation, rooms, and student allocations"
      icon={<Building2 className="h-12 w-12 text-primary" />}
    />
  )
}
