import ComingSoonPage from '@/components/coming-soon-page'
import { MessageSquare } from 'lucide-react'

export default function MessagesPage() {
  return (
    <ComingSoonPage
      title="Parent-Teacher Communication"
      description="Messaging system for effective communication between parents and teachers"
      icon={<MessageSquare className="h-12 w-12 text-primary" />}
    />
  )
}
