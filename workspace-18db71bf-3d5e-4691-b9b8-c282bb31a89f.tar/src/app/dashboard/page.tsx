'use client'

import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Users,
  GraduationCap,
  ClipboardCheck,
  BookOpen,
  TrendingUp,
  TrendingDown,
  Clock,
  AlertCircle
} from 'lucide-react'

export default function DashboardPage() {
  const stats = [
    {
      title: 'Total Students',
      value: '2,450',
      change: '+12.5%',
      trend: 'up',
      icon: Users,
      description: 'vs last semester'
    },
    {
      title: 'Teachers',
      value: '156',
      change: '+3',
      trend: 'up',
      icon: GraduationCap,
      description: 'new hires this month'
    },
    {
      title: 'Today\'s Attendance',
      value: '96.2%',
      change: '-1.2%',
      trend: 'down',
      icon: ClipboardCheck,
      description: 'overall attendance'
    },
    {
      title: 'Active Courses',
      value: '89',
      change: '+5',
      trend: 'up',
      icon: BookOpen,
      description: 'courses this semester'
    }
  ]

  const recentActivities = [
    {
      id: 1,
      type: 'student',
      title: 'New student enrolled',
      description: 'Sarah Johnson enrolled in Grade 10-A',
      time: '2 hours ago',
      status: 'success'
    },
    {
      id: 2,
      type: 'attendance',
      title: 'Attendance report generated',
      description: 'Weekly attendance report for Grade 9',
      time: '3 hours ago',
      status: 'info'
    },
    {
      id: 3,
      type: 'exam',
      title: 'Exam results published',
      description: 'Mathematics midterm results for Grade 11',
      time: '5 hours ago',
      status: 'success'
    },
    {
      id: 4,
      type: 'alert',
      title: 'Low attendance alert',
      description: '15 students below 75% attendance',
      time: '6 hours ago',
      status: 'warning'
    },
    {
      id: 5,
      type: 'library',
      title: 'Library book overdue',
      description: '23 books overdue this week',
      time: '8 hours ago',
      status: 'warning'
    }
  ]

  const upcomingEvents = [
    {
      id: 1,
      title: 'Parent-Teacher Meeting',
      date: 'Tomorrow, 10:00 AM',
      type: 'meeting'
    },
    {
      id: 2,
      title: 'Science Fair',
      date: 'March 15, 2025',
      type: 'event'
    },
    {
      id: 3,
      title: 'Midterm Exams Begin',
      date: 'March 20, 2025',
      type: 'exam'
    },
    {
      id: 4,
      title: 'Sports Day',
      date: 'March 28, 2025',
      type: 'event'
    }
  ]

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Welcome back! Here's what's happening in your school today.
            </p>
          </div>
          <Button>New Quick Action</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                  {stat.trend === 'up' ? (
                    <TrendingUp className="h-3 w-3 text-green-500" />
                  ) : (
                    <TrendingDown className="h-3 w-3 text-red-500" />
                  )}
                  <span className={stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}>
                    {stat.change}
                  </span>
                  <span className="text-muted-foreground ml-1">{stat.description}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Recent Activities */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent transition-colors"
                  >
                    <div
                      className={`mt-0.5 h-2 w-2 rounded-full ${
                        activity.status === 'success'
                          ? 'bg-green-500'
                          : activity.status === 'warning'
                          ? 'bg-orange-500'
                          : 'bg-blue-500'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{activity.title}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        {activity.description}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {activity.time}
                      </p>
                    </div>
                    <Badge
                      variant={
                        activity.status === 'success'
                          ? 'default'
                          : activity.status === 'warning'
                          ? 'destructive'
                          : 'secondary'
                      }
                      className="ml-auto"
                    >
                      {activity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingEvents.map((event) => (
                  <div
                    key={event.id}
                    className="p-3 rounded-lg border hover:bg-accent transition-colors"
                  >
                    <div className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">
                        {event.type}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{event.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {event.date}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Access Cards */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Quick Access</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Add Student</p>
                    <p className="text-sm text-muted-foreground">
                      Register new student
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <ClipboardCheck className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Take Attendance</p>
                    <p className="text-sm text-muted-foreground">
                      Mark daily attendance
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Create Lesson</p>
                    <p className="text-sm text-muted-foreground">
                      Plan new lesson
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <AlertCircle className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">View Reports</p>
                    <p className="text-sm text-muted-foreground">
                      Analytics & insights
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
