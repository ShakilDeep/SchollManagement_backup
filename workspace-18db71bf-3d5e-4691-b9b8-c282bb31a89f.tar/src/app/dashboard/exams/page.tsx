'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Input } from '@/components/ui/input'
import { Plus, Download, FileText, BarChart3, TrendingUp } from 'lucide-react'

interface Exam {
  id: string
  name: string
  type: string
  subject: string
  grade: string
  date: string
  status: string
  totalMarks: number
}

interface ExamResult {
  id: string
  studentName: string
  rollNumber: string
  subject: string
  marksObtained: number
  totalMarks: number
  percentage: number
  grade: string
  rank: number
}

const mockExams: Exam[] = [
  {
    id: '1',
    name: 'Midterm Examination',
    type: 'Midterm',
    subject: 'Mathematics',
    grade: 'Grade 10',
    date: '2025-03-20',
    status: 'Completed',
    totalMarks: 100
  },
  {
    id: '2',
    name: 'Unit Test 2',
    type: 'Unit Test',
    subject: 'Science',
    grade: 'Grade 10',
    date: '2025-03-25',
    status: 'Upcoming',
    totalMarks: 50
  },
  {
    id: '3',
    name: 'Final Examination',
    type: 'Final',
    subject: 'English',
    grade: 'Grade 10',
    date: '2025-06-15',
    status: 'Upcoming',
    totalMarks: 100
  }
]

const mockResults: ExamResult[] = [
  {
    id: '1',
    studentName: 'Sarah Johnson',
    rollNumber: '2024-001',
    subject: 'Mathematics',
    marksObtained: 85,
    totalMarks: 100,
    percentage: 85,
    grade: 'A',
    rank: 2
  },
  {
    id: '2',
    studentName: 'David Smith',
    rollNumber: '2024-002',
    subject: 'Mathematics',
    marksObtained: 92,
    totalMarks: 100,
    percentage: 92,
    grade: 'A+',
    rank: 1
  },
  {
    id: '3',
    studentName: 'Emily Brown',
    rollNumber: '2024-003',
    subject: 'Mathematics',
    marksObtained: 78,
    totalMarks: 100,
    percentage: 78,
    grade: 'B+',
    rank: 4
  },
  {
    id: '4',
    studentName: 'James Wilson',
    rollNumber: '2024-004',
    subject: 'Mathematics',
    marksObtained: 88,
    totalMarks: 100,
    percentage: 88,
    grade: 'A',
    rank: 3
  },
  {
    id: '5',
    studentName: 'Sophia Davis',
    rollNumber: '2024-005',
    subject: 'Mathematics',
    marksObtained: 72,
    totalMarks: 100,
    percentage: 72,
    grade: 'B',
    rank: 5
  }
]

export default function ExamsPage() {
  const [selectedExam, setSelectedExam] = useState<string>('1')
  const [searchTerm, setSearchTerm] = useState('')

  const currentExam = mockExams.find(e => e.id === selectedExam)
  const filteredResults = mockResults.filter(result =>
    result.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    result.rollNumber.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const stats = {
    average: mockResults.reduce((acc, r) => acc + r.percentage, 0) / mockResults.length,
    highest: Math.max(...mockResults.map(r => r.percentage)),
    lowest: Math.min(...mockResults.map(r => r.percentage)),
    passed: mockResults.filter(r => r.percentage >= 40).length,
    failed: mockResults.filter(r => r.percentage < 40).length
  }

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
    if (grade.startsWith('B')) return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300'
    if (grade.startsWith('C')) return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300'
    return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      'Completed': 'default',
      'Upcoming': 'secondary',
      'Ongoing': 'default'
    }
    return <Badge variant={variants[status]}>{status}</Badge>
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Exams & Results</h1>
            <p className="text-muted-foreground mt-1">
              Manage examinations, publish results, and track performance
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Results
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Exam
            </Button>
          </div>
        </div>

        <Tabs defaultValue="exams" className="space-y-4">
          <TabsList>
            <TabsTrigger value="exams">
              <FileText className="mr-2 h-4 w-4" />
              Exams
            </TabsTrigger>
            <TabsTrigger value="results">
              <BarChart3 className="mr-2 h-4 w-4" />
              Results
            </TabsTrigger>
          </TabsList>

          {/* Exams Tab */}
          <TabsContent value="exams" className="space-y-4">
            {/* Exams List */}
            <Card>
              <CardHeader>
                <CardTitle>Upcoming & Recent Exams</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockExams.map((exam) => (
                    <div key={exam.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold">{exam.name}</h3>
                          <Badge variant="outline">{exam.type}</Badge>
                          {getStatusBadge(exam.status)}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {exam.subject} • {exam.grade} • {exam.date} • Total: {exam.totalMarks} marks
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                        {exam.status === 'Upcoming' && (
                          <Button size="sm">
                            Schedule
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-4">
            {/* Select Exam */}
            <Card>
              <CardHeader>
                <CardTitle>Select Exam</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <div className="flex-1 max-w-md">
                    <Label>Exam</Label>
                    <Select value={selectedExam} onValueChange={setSelectedExam}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an exam" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockExams.filter(e => e.status === 'Completed').map((exam) => (
                          <SelectItem key={exam.id} value={exam.id}>
                            {exam.name} - {exam.subject}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {currentExam && (
                    <div className="flex-1">
                      <Label>Exam Details</Label>
                      <div className="p-3 bg-muted rounded mt-2 text-sm">
                        <div><strong>Subject:</strong> {currentExam.subject}</div>
                        <div><strong>Grade:</strong> {currentExam.grade}</div>
                        <div><strong>Date:</strong> {currentExam.date}</div>
                        <div><strong>Total Marks:</strong> {currentExam.totalMarks}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Statistics */}
            <div className="grid gap-4 md:grid-cols-5">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Average Score</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.average.toFixed(1)}%</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Highest Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{stats.highest}%</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Lowest Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">{stats.lowest}%</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Passed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{stats.passed}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {((stats.passed / mockResults.length) * 100).toFixed(0)}%
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Failed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{stats.failed}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {((stats.failed / mockResults.length) * 100).toFixed(0)}%
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Results Table */}
            <Card>
              <CardHeader>
                <CardTitle>Exam Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <Input
                    placeholder="Search by student name or roll number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Rank</TableHead>
                        <TableHead>Roll Number</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Marks Obtained</TableHead>
                        <TableHead>Total Marks</TableHead>
                        <TableHead>Percentage</TableHead>
                        <TableHead>Grade</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredResults.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                            No results found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredResults.map((result) => (
                          <TableRow key={result.id}>
                            <TableCell>
                              <Badge variant={result.rank <= 3 ? 'default' : 'secondary'}>
                                #{result.rank}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">{result.rollNumber}</TableCell>
                            <TableCell>{result.studentName}</TableCell>
                            <TableCell>{result.subject}</TableCell>
                            <TableCell>{result.marksObtained}</TableCell>
                            <TableCell>{result.totalMarks}</TableCell>
                            <TableCell>
                              <span className={`font-semibold ${
                                result.percentage >= 80 ? 'text-green-600' :
                                result.percentage >= 60 ? 'text-blue-600' :
                                result.percentage >= 40 ? 'text-yellow-600' : 'text-red-600'
                              }`}>
                                {result.percentage}%
                              </span>
                            </TableCell>
                            <TableCell>
                              <Badge className={getGradeColor(result.grade)}>
                                {result.grade}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
