import ComingSoonPage from '@/components/coming-soon-page'
import { ScrollText } from 'lucide-react'

export default function CurriculumPage() {
  return (
    <ComingSoonPage
      title="Curriculum & Lesson Planning"
      description="Plan lessons, manage curriculum, and track educational content"
      icon={<ScrollText className="h-12 w-12 text-primary" />}
    />
  )
}
