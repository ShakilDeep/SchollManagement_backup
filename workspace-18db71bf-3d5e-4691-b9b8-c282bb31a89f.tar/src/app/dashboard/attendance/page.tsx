'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Calendar } from '@/components/ui/calendar'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { CalendarIcon, Download, Save, RefreshCw } from 'lucide-react'
import { format } from 'date-fns'

interface StudentAttendance {
  id: string
  rollNumber: string
  name: string
  grade: string
  section: string
  status: 'Present' | 'Absent' | 'Late' | 'HalfDay'
  checkIn?: string
  checkOut?: string
}

const mockAttendanceData: StudentAttendance[] = [
  {
    id: '1',
    rollNumber: '2024-001',
    name: 'Sarah Johnson',
    grade: 'Grade 10',
    section: 'A',
    status: 'Present',
    checkIn: '08:30 AM',
    checkOut: '02:30 PM'
  },
  {
    id: '2',
    rollNumber: '2024-002',
    name: 'David Smith',
    grade: 'Grade 10',
    section: 'B',
    status: 'Present',
    checkIn: '08:25 AM',
    checkOut: '02:30 PM'
  },
  {
    id: '3',
    rollNumber: '2024-003',
    name: 'Emily Brown',
    grade: 'Grade 9',
    section: 'A',
    status: 'Late',
    checkIn: '09:15 AM',
    checkOut: '02:30 PM'
  },
  {
    id: '4',
    rollNumber: '2024-004',
    name: 'James Wilson',
    grade: 'Grade 11',
    section: 'C',
    status: 'Present',
    checkIn: '08:20 AM',
    checkOut: '02:30 PM'
  },
  {
    id: '5',
    rollNumber: '2024-005',
    name: 'Sophia Davis',
    grade: 'Grade 9',
    section: 'B',
    status: 'Absent'
  },
  {
    id: '6',
    rollNumber: '2024-006',
    name: 'Michael Lee',
    grade: 'Grade 10',
    section: 'A',
    status: 'HalfDay',
    checkIn: '08:30 AM',
    checkOut: '12:00 PM'
  }
]

export default function AttendancePage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [grade, setGrade] = useState('')
  const [section, setSection] = useState('')
  const [attendanceData, setAttendanceData] = useState<StudentAttendance[]>(mockAttendanceData)

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      Present: 'default',
      Absent: 'destructive',
      Late: 'secondary',
      HalfDay: 'secondary'
    }
    return <Badge variant={variants[status]}>{status}</Badge>
  }

  const handleStatusChange = (studentId: string, newStatus: StudentAttendance['status']) => {
    setAttendanceData(prev =>
      prev.map(student =>
        student.id === studentId
          ? { ...student, status: newStatus }
          : student
      )
    )
  }

  const stats = {
    total: attendanceData.length,
    present: attendanceData.filter((s) => s.status === 'Present').length,
    absent: attendanceData.filter((s) => s.status === 'Absent').length,
    late: attendanceData.filter((s) => s.status === 'Late').length,
    halfDay: attendanceData.filter((s) => s.status === 'HalfDay').length
  }

  const attendanceRate = stats.total > 0
    ? ((stats.present + stats.late + stats.halfDay) / stats.total * 100).toFixed(1)
    : '0'

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Attendance</h1>
            <p className="text-muted-foreground mt-1">
              Track and manage student attendance records
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Select Class & Date</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-[200px] justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Grade</Label>
                <Select value={grade} onValueChange={setGrade}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="9">Grade 9</SelectItem>
                    <SelectItem value="10">Grade 10</SelectItem>
                    <SelectItem value="11">Grade 11</SelectItem>
                    <SelectItem value="12">Grade 12</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Section</Label>
                <Select value={section} onValueChange={setSection}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select section" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Section A</SelectItem>
                    <SelectItem value="B">Section B</SelectItem>
                    <SelectItem value="C">Section C</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Present</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.present}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {((stats.present / stats.total) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Absent</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.absent}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {((stats.absent / stats.total) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Late</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.late}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {((stats.late / stats.total) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Half Day</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{stats.halfDay}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {((stats.halfDay / stats.total) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Attendance Summary */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Today's Attendance: {attendanceRate}%</CardTitle>
              <Button>
                <Save className="mr-2 h-4 w-4" />
                Save Attendance
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="w-full bg-gray-200 rounded-full h-3 mb-6">
              <div
                className="bg-green-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${attendanceRate}%` }}
              />
            </div>

            {/* Attendance Table */}
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Roll Number</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendanceData.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.rollNumber}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.grade}</TableCell>
                      <TableCell>{student.section}</TableCell>
                      <TableCell>
                        <Select
                          value={student.status}
                          onValueChange={(value) => handleStatusChange(student.id, value as StudentAttendance['status'])}
                        >
                          <SelectTrigger className="w-[140px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Present">Present</SelectItem>
                            <SelectItem value="Absent">Absent</SelectItem>
                            <SelectItem value="Late">Late</SelectItem>
                            <SelectItem value="HalfDay">Half Day</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>{student.checkIn || '-'}</TableCell>
                      <TableCell>{student.checkOut || '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
