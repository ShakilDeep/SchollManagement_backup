import ComingSoonPage from '@/components/coming-soon-page'
import { Bus } from 'lucide-react'

export default function TransportPage() {
  return (
    <ComingSoonPage
      title="Transport Management"
      description="Manage school transportation, vehicles, and routes"
      icon={<Bus className="h-12 w-12 text-primary" />}
    />
  )
}
