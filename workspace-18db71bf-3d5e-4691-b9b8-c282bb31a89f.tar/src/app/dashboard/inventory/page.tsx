import ComingSoonPage from '@/components/coming-soon-page'
import { Package } from 'lucide-react'

export default function InventoryPage() {
  return (
    <ComingSoonPage
      title="Inventory & Asset Management"
      description="Track and manage school assets, inventory, and equipment"
      icon={<Package className="h-12 w-12 text-primary" />}
    />
  )
}
