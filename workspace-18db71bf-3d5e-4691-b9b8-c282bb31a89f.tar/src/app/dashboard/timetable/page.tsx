'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Plus, Print, Download } from 'lucide-react'

interface Period {
  period: number
  time: string
  day: string
  subject: string
  teacher: string
  room: string
}

const mockTimetableData: Record<string, Period[]> = {
  'Grade 10-A': [
    { period: 1, time: '08:00 - 08:45', day: 'Monday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 2, time: '08:50 - 09:35', day: 'Monday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 3, time: '09:40 - 10:25', day: 'Monday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 4, time: '10:40 - 11:25', day: 'Monday', subject: 'History', teacher: 'Mr. Wilson', room: 'Room 103' },
    { period: 5, time: '11:30 - 12:15', day: 'Monday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 6, time: '12:40 - 01:25', day: 'Monday', subject: 'Physical Ed', teacher: 'Coach Miller', room: 'Gym' },
    { period: 7, time: '01:30 - 02:15', day: 'Monday', subject: 'Art', teacher: 'Ms. Davis', room: 'Art Room' },
    { period: 8, time: '02:20 - 03:05', day: 'Monday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },

    { period: 1, time: '08:00 - 08:45', day: 'Tuesday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 2, time: '08:50 - 09:35', day: 'Tuesday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 3, time: '09:40 - 10:25', day: 'Tuesday', subject: 'Geography', teacher: 'Ms. Taylor', room: 'Room 104' },
    { period: 4, time: '10:40 - 11:25', day: 'Tuesday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 5, time: '11:30 - 12:15', day: 'Tuesday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 6, time: '12:40 - 01:25', day: 'Tuesday', subject: 'Music', teacher: 'Mr. Anderson', room: 'Music Room' },
    { period: 7, time: '01:30 - 02:15', day: 'Tuesday', subject: 'Computer', teacher: 'Ms. Lee', room: 'Computer Lab' },
    { period: 8, time: '02:20 - 03:05', day: 'Tuesday', subject: 'History', teacher: 'Mr. Wilson', room: 'Room 103' },

    { period: 1, time: '08:00 - 08:45', day: 'Wednesday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 2, time: '08:50 - 09:35', day: 'Wednesday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 3, time: '09:40 - 10:25', day: 'Wednesday', subject: 'Physical Ed', teacher: 'Coach Miller', room: 'Gym' },
    { period: 4, time: '10:40 - 11:25', day: 'Wednesday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 5, time: '11:30 - 12:15', day: 'Wednesday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 6, time: '12:40 - 01:25', day: 'Wednesday', subject: 'Art', teacher: 'Ms. Davis', room: 'Art Room' },
    { period: 7, time: '01:30 - 02:15', day: 'Wednesday', subject: 'History', teacher: 'Mr. Wilson', room: 'Room 103' },
    { period: 8, time: '02:20 - 03:05', day: 'Wednesday', subject: 'Geography', teacher: 'Ms. Taylor', room: 'Room 104' },

    { period: 1, time: '08:00 - 08:45', day: 'Thursday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 2, time: '08:50 - 09:35', day: 'Thursday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 3, time: '09:40 - 10:25', day: 'Thursday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 4, time: '10:40 - 11:25', day: 'Thursday', subject: 'Computer', teacher: 'Ms. Lee', room: 'Computer Lab' },
    { period: 5, time: '11:30 - 12:15', day: 'Thursday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 6, time: '12:40 - 01:25', day: 'Thursday', subject: 'Geography', teacher: 'Ms. Taylor', room: 'Room 104' },
    { period: 7, time: '01:30 - 02:15', day: 'Thursday', subject: 'Physical Ed', teacher: 'Coach Miller', room: 'Gym' },
    { period: 8, time: '02:20 - 03:05', day: 'Thursday', subject: 'Art', teacher: 'Ms. Davis', room: 'Art Room' },

    { period: 1, time: '08:00 - 08:45', day: 'Friday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 2, time: '08:50 - 09:35', day: 'Friday', subject: 'History', teacher: 'Mr. Wilson', room: 'Room 103' },
    { period: 3, time: '09:40 - 10:25', day: 'Friday', subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 101' },
    { period: 4, time: '10:40 - 11:25', day: 'Friday', subject: 'Science', teacher: 'Dr. Brown', room: 'Lab 1' },
    { period: 5, time: '11:30 - 12:15', day: 'Friday', subject: 'English', teacher: 'Ms. Smith', room: 'Room 102' },
    { period: 6, time: '12:40 - 01:25', day: 'Friday', subject: 'Music', teacher: 'Mr. Anderson', room: 'Music Room' },
    { period: 7, time: '01:30 - 02:15', day: 'Friday', subject: 'Computer', teacher: 'Ms. Lee', room: 'Computer Lab' },
    { period: 8, time: '02:20 - 03:05', day: 'Friday', subject: 'Geography', teacher: 'Ms. Taylor', room: 'Room 104' },
  ]
}

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
const subjectColors: Record<string, string> = {
  'Mathematics': 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  'English': 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  'Science': 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
  'History': 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
  'Geography': 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300',
  'Physical Ed': 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  'Art': 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
  'Music': 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300',
  'Computer': 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
}

export default function TimetablePage() {
  const [grade, setGrade] = useState('10')
  const [section, setSection] = useState('A')
  const [viewType, setViewType] = useState<'weekly' | 'daily'>('weekly')

  const classKey = `Grade ${grade}-${section}`
  const timetableData = mockTimetableData[classKey] || []

  const getPeriodsForDay = (day: string) => {
    return timetableData.filter((p) => p.day === day)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Timetable</h1>
            <p className="text-muted-foreground mt-1">
              View and manage class schedules and timetables
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Print className="mr-2 h-4 w-4" />
              Print
            </Button>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Schedule
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Select Class</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="space-y-2">
                <Label>Grade</Label>
                <Select value={grade} onValueChange={setGrade}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="9">Grade 9</SelectItem>
                    <SelectItem value="10">Grade 10</SelectItem>
                    <SelectItem value="11">Grade 11</SelectItem>
                    <SelectItem value="12">Grade 12</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Section</Label>
                <Select value={section} onValueChange={setSection}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select section" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Section A</SelectItem>
                    <SelectItem value="B">Section B</SelectItem>
                    <SelectItem value="C">Section C</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>View</Label>
                <Select value={viewType} onValueChange={(v) => setViewType(v as 'weekly' | 'daily')}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly View</SelectItem>
                    <SelectItem value="daily">Daily View</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Timetable */}
        {viewType === 'weekly' && (
          <Card>
            <CardHeader>
              <CardTitle>Weekly Schedule - Grade {grade}-{section}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="p-2 text-left font-medium text-sm bg-muted">Period / Time</th>
                      {days.map((day) => (
                        <th key={day} className="p-2 text-center font-medium text-sm bg-muted min-w-[140px]">
                          {day}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((period) => (
                      <tr key={period} className="border-b">
                        <td className="p-2 font-medium text-sm bg-muted/50">
                          Period {period}
                        </td>
                        {days.map((day) => {
                          const periodData = getPeriodsForDay(day).find(p => p.period === period)
                          const subject = periodData?.subject || 'Free Period'
                          return (
                            <td key={`${day}-${period}`} className="p-1">
                              {periodData ? (
                                <div className={`p-2 rounded text-xs min-h-[80px] ${subjectColors[subject] || 'bg-gray-100'}`}>
                                  <div className="font-semibold mb-1">{subject}</div>
                                  <div className="text-xs opacity-90">{periodData.teacher}</div>
                                  <div className="text-xs opacity-75">{periodData.room}</div>
                                </div>
                              ) : (
                                <div className="p-2 text-xs text-muted-foreground min-h-[80px] flex items-center justify-center">
                                  Free Period
                                </div>
                              )}
                            </td>
                          )
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Daily View */}
        {viewType === 'daily' && (
          <Card>
            <CardHeader>
              <CardTitle>Daily Schedule - Grade {grade}-{section}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {days.map((day) => (
                  <div key={day}>
                    <h3 className="font-semibold text-lg mb-2">{day}</h3>
                    <div className="space-y-2">
                      {getPeriodsForDay(day).map((period) => (
                        <div key={`${day}-${period.period}`} className="flex items-center gap-4 p-3 border rounded-lg">
                          <div className="flex-shrink-0 w-32">
                            <div className="font-medium">Period {period.period}</div>
                            <div className="text-xs text-muted-foreground">{period.time}</div>
                          </div>
                          <div className={`flex-1 p-3 rounded ${subjectColors[period.subject] || 'bg-gray-100'}`}>
                            <div className="font-semibold">{period.subject}</div>
                            <div className="text-sm opacity-90">Teacher: {period.teacher}</div>
                            <div className="text-sm opacity-75">Room: {period.room}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Legend */}
        <Card>
          <CardHeader>
            <CardTitle>Subject Legend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {Object.entries(subjectColors).map(([subject, color]) => (
                <Badge key={subject} className={color}>
                  {subject}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
