'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Plus,
  Search,
  MoreVertical,
  BookOpen,
  Users,
  AlertTriangle,
  CheckCircle2,
  Filter
} from 'lucide-react'

interface Book {
  id: string
  isbn: string
  title: string
  author: string
  category: string
  totalCopies: number
  availableCopies: number
  location: string
}

interface Borrowal {
  id: string
  bookTitle: string
  studentName: string
  borrowDate: string
  dueDate: string
  returnDate?: string
  status: 'Borrowed' | 'Returned' | 'Overdue'
  fine: number
}

const mockBooks: Book[] = [
  {
    id: '1',
    isbn: '978-3-16-148410-0',
    title: 'Introduction to Algorithms',
    author: 'Thomas H. Cormen',
    category: 'Computer Science',
    totalCopies: 5,
    availableCopies: 2,
    location: 'Shelf A-1'
  },
  {
    id: '2',
    isbn: '978-0-13-468599-1',
    title: 'Effective Java',
    author: 'Joshua Bloch',
    category: 'Programming',
    totalCopies: 3,
    availableCopies: 1,
    location: 'Shelf A-2'
  },
  {
    id: '3',
    isbn: '978-0-201-63361-0',
    title: 'Design Patterns',
    author: 'Erich Gamma',
    category: 'Software Engineering',
    totalCopies: 4,
    availableCopies: 0,
    location: 'Shelf B-1'
  },
  {
    id: '4',
    isbn: '978-0-07-352332-8',
    title: 'Physics for Scientists and Engineers',
    author: 'Raymond A. Serway',
    category: 'Science',
    totalCopies: 10,
    availableCopies: 7,
    location: 'Shelf C-1'
  },
  {
    id: '5',
    isbn: '978-0-13-110362-7',
    title: 'The C Programming Language',
    author: 'Brian W. Kernighan',
    category: 'Programming',
    totalCopies: 6,
    availableCopies: 4,
    location: 'Shelf A-3'
  }
]

const mockBorrowals: Borrowal[] = [
  {
    id: '1',
    bookTitle: 'Introduction to Algorithms',
    studentName: 'Sarah Johnson',
    borrowDate: '2025-02-20',
    dueDate: '2025-03-06',
    status: 'Overdue',
    fine: 5.00
  },
  {
    id: '2',
    bookTitle: 'Physics for Scientists and Engineers',
    studentName: 'David Smith',
    borrowDate: '2025-02-25',
    dueDate: '2025-03-10',
    status: 'Borrowed',
    fine: 0
  },
  {
    id: '3',
    bookTitle: 'Effective Java',
    studentName: 'Emily Brown',
    borrowDate: '2025-02-15',
    dueDate: '2025-03-01',
    returnDate: '2025-02-28',
    status: 'Returned',
    fine: 0
  },
  {
    id: '4',
    bookTitle: 'Design Patterns',
    studentName: 'James Wilson',
    borrowDate: '2025-02-10',
    dueDate: '2025-02-25',
    status: 'Overdue',
    fine: 8.00
  },
  {
    id: '5',
    bookTitle: 'The C Programming Language',
    studentName: 'Sophia Davis',
    borrowDate: '2025-03-01',
    dueDate: '2025-03-15',
    status: 'Borrowed',
    fine: 0
  }
]

export default function LibraryPage() {
  const [books] = useState<Book[]>(mockBooks)
  const [borrowals] = useState<Borrowal[]>(mockBorrowals)
  const [searchTerm, setSearchTerm] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [isAddBookOpen, setIsAddBookOpen] = useState(false)

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.isbn.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === 'all' || book.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const stats = {
    totalBooks: books.reduce((acc, b) => acc + b.totalCopies, 0),
    availableBooks: books.reduce((acc, b) => acc + b.availableCopies, 0),
    borrowed: mockBorrowals.filter(b => b.status === 'Borrowed').length,
    overdue: mockBorrowals.filter(b => b.status === 'Overdue').length,
    returned: mockBorrowals.filter(b => b.status === 'Returned').length
  }

  const getAvailabilityBadge = (book: Book) => {
    if (book.availableCopies === 0) {
      return <Badge variant="destructive">Out of Stock</Badge>
    }
    if (book.availableCopies < 2) {
      return <Badge variant="secondary">Low Stock</Badge>
    }
    return <Badge variant="default">Available</Badge>
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      'Borrowed': 'default',
      'Returned': 'secondary',
      'Overdue': 'destructive'
    }
    return <Badge variant={variants[status]}>{status}</Badge>
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Library</h1>
            <p className="text-muted-foreground mt-1">
              Manage library books, borrowing, and returns
            </p>
          </div>
          <Dialog open={isAddBookOpen} onOpenChange={setIsAddBookOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Book
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Book</DialogTitle>
                <DialogDescription>
                  Enter the book details to add it to the library
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Book Title *</Label>
                  <Input id="title" placeholder="Enter book title" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="author">Author *</Label>
                    <Input id="author" placeholder="Author name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="isbn">ISBN *</Label>
                    <Input id="isbn" placeholder="978-0-00-000000-0" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Computer Science">Computer Science</SelectItem>
                        <SelectItem value="Programming">Programming</SelectItem>
                        <SelectItem value="Science">Science</SelectItem>
                        <SelectItem value="Mathematics">Mathematics</SelectItem>
                        <SelectItem value="Literature">Literature</SelectItem>
                        <SelectItem value="History">History</SelectItem>
                        <SelectItem value="Geography">Geography</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="copies">Total Copies *</Label>
                    <Input id="copies" type="number" placeholder="Number of copies" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location *</Label>
                  <Input id="location" placeholder="e.g., Shelf A-1" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="publisher">Publisher</Label>
                  <Input id="publisher" placeholder="Publisher name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Publication Year</Label>
                  <Input id="year" type="number" placeholder="2024" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Brief description of the book" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddBookOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsAddBookOpen(false)}>
                  Add Book
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Books</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalBooks}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.availableBooks}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Borrowed</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.borrowed}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overdue</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Returned</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{stats.returned}</div>
            </CardContent>
          </Card>
        </div>

        {/* Books Catalog */}
        <Card>
          <CardHeader>
            <CardTitle>Books Catalog</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by title, author, or ISBN..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Computer Science">Computer Science</SelectItem>
                  <SelectItem value="Programming">Programming</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                  <SelectItem value="Literature">Literature</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ISBN</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Author</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Total Copies</TableHead>
                    <TableHead>Available</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBooks.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                        No books found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredBooks.map((book) => (
                      <TableRow key={book.id}>
                        <TableCell className="font-medium text-xs">{book.isbn}</TableCell>
                        <TableCell>{book.title}</TableCell>
                        <TableCell>{book.author}</TableCell>
                        <TableCell>{book.category}</TableCell>
                        <TableCell>{book.totalCopies}</TableCell>
                        <TableCell>
                          <span className={`font-semibold ${
                            book.availableCopies === 0 ? 'text-red-600' :
                            book.availableCopies < 2 ? 'text-orange-600' : 'text-green-600'
                          }`}>
                            {book.availableCopies}
                          </span>
                        </TableCell>
                        <TableCell>{book.location}</TableCell>
                        <TableCell>{getAvailabilityBadge(book)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Borrowals */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Borrowals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Book Title</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead>Borrow Date</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Return Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Fine</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {borrowals.slice(0, 5).map((borrowal) => (
                    <TableRow key={borrowal.id}>
                      <TableCell className="font-medium">{borrowal.bookTitle}</TableCell>
                      <TableCell>{borrowal.studentName}</TableCell>
                      <TableCell>{borrowal.borrowDate}</TableCell>
                      <TableCell>{borrowal.dueDate}</TableCell>
                      <TableCell>{borrowal.returnDate || '-'}</TableCell>
                      <TableCell>{getStatusBadge(borrowal.status)}</TableCell>
                      <TableCell>
                        <span className={borrowal.fine > 0 ? 'text-red-600 font-semibold' : ''}>
                          ${borrowal.fine.toFixed(2)}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
